# MySQL database access functions

## Warning

This extension is deprecated and unmaintained.

## Description

This extension provides the mysql family of functions that were provided with
PHP 3-5. These functions have been superseded by MySQLi and PDO_MySQL, which
continue to be bundled with PHP 7.

Although it should be possible to build this extension with PHP 7.0, you are
strongly encouraged to port your code to use either MySQLi or PDO_MySQL, as
this extension is not maintained and is available for historical reasons only.
